package com.example.smsreader;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Pattern;

import static android.view.View.INVISIBLE;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayList<String> items;
    private Button readSmsButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         readSmsButton = findViewById(R.id.button);
        //readSmsButton.setVisibility(View.VISIBLE);
        setContentView(R.layout.activity_main);
       // textView = findViewById(R.id.textView);
        listView = findViewById(R.id.listView);
        final PackageManager pm = getPackageManager();
//get a list of installed apps.
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        for (ApplicationInfo packageInfo : packages) {
            Log.i("TAG", "Installed package :" + packageInfo.packageName);
            Log.i("TAG", "Source dir : " + packageInfo.sourceDir);
            Log.i("TAG", "Launch Activity :" + pm.getLaunchIntentForPackage(packageInfo.packageName));
        }
        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_SMS} , PackageManager.PERMISSION_GRANTED);
        readSms();
    }
    public void readSms(){
//        if(!items.isEmpty())
//        {
//            Toast.makeText(getApplicationContext(),"Messages are already loaded",Toast.LENGTH_SHORT).show();
//            Log.i("error :","its here");
//        }
          //  readSmsButton.setVisibility(INVISIBLE);
            String[] reqCols = new String[]{"address", "body"};
            String msgData = "";
            Cursor cursor = getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null);
            items = new ArrayList<>();
            if (cursor.moveToFirst()) {
                // Adapter adapter = new SimpleCursorAdapter(this,R.layout.activity_main,cursor,reqCols,new int[]{R.id.})
                do {
                    String msg = cursor.getString(12);
                    if (Pattern.matches(".*Rs.*", msg) || Pattern.matches(".*Rs.[1-9]+ *.", msg))
                        items.add(msg);
                } while (cursor.moveToNext());

            }

            ArrayAdapter<String> itemsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, items);

//        textView.setText(cursor.getString(12));
            listView.setAdapter(itemsAdapter);

    }

}
